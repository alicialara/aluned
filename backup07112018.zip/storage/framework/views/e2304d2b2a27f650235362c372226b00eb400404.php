<?php $__env->startSection('content'); ?>
    <div id="category">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createCategories')): ?>
            <?php echo $__env->make('forum::category.partials.form-create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>

        <h2>
            <?php echo e($category->title); ?>

            <?php if($category->description): ?>
                <small><?php echo e($category->description); ?></small>
            <?php endif; ?>
        </h2>

        <hr>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manageCategories')): ?>
            <form action="<?php echo e(Forum::route('category.update', $category)); ?>" method="POST" data-actions-form>
                <?php echo csrf_field(); ?>

                <?php echo method_field('patch'); ?>


                <?php echo $__env->make('forum::category.partials.actions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </form>
        <?php endif; ?>

        <?php if(!$category->children->isEmpty()): ?>
            <table class="table table-category">
                <thead>
                    <tr>
                        <th><?php echo e(trans_choice('forum::categories.category', 1)); ?></th>
                        <th class="col-md-2"><?php echo e(trans_choice('forum::threads.thread', 2)); ?></th>
                        <th class="col-md-2"><?php echo e(trans_choice('forum::posts.post', 2)); ?></th>
                        <th class="col-md-2"><?php echo e(trans('forum::threads.newest')); ?></th>
                        <th class="col-md-2"><?php echo e(trans('forum::posts.last')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('forum::category.partials.list', ['category' => $subcategory], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>

        <div class="row">
            <div class="col-xs-4">
                <?php if($category->threadsEnabled): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createThreads', $category)): ?>
                        <a href="<?php echo e(Forum::route('thread.create', $category)); ?>" class="btn btn-primary"><?php echo e(trans('forum::threads.new_thread')); ?></a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="col-xs-8 text-right">
                <?php echo $threads->render(); ?>

            </div>
        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manageThreads', $category)): ?>
            <form action="<?php echo e(Forum::route('bulk.thread.update')); ?>" method="POST" data-actions-form>
                <?php echo csrf_field(); ?>

                <?php echo method_field('delete'); ?>

        <?php endif; ?>

        <?php if($category->threadsEnabled): ?>
            <table class="table table-thread">
                <thead>
                    <tr>
                        <th><?php echo e(trans('forum::general.subject')); ?></th>
                        <th class="col-md-2 text-right"><?php echo e(trans('forum::general.replies')); ?></th>
                        <th class="col-md-2 text-right"><?php echo e(trans('forum::posts.last')); ?></th>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manageThreads', $category)): ?>
                            <th class="col-md-1 text-right"><input type="checkbox" data-toggle-all></th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!$threads->isEmpty()): ?>
                        <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e($thread->trashed() ? "deleted" : ""); ?>">
                                <td>
                                    <span class="pull-right">
                                        <?php if($thread->locked): ?>
                                            <span class="label label-warning"><?php echo e(trans('forum::threads.locked')); ?></span>
                                        <?php endif; ?>
                                        <?php if($thread->pinned): ?>
                                            <span class="label label-info"><?php echo e(trans('forum::threads.pinned')); ?></span>
                                        <?php endif; ?>
                                        <?php if($thread->userReadStatus && !$thread->trashed()): ?>
                                            <span class="label label-primary"><?php echo e(trans($thread->userReadStatus)); ?></span>
                                        <?php endif; ?>
                                        <?php if($thread->trashed()): ?>
                                            <span class="label label-danger"><?php echo e(trans('forum::general.deleted')); ?></span>
                                        <?php endif; ?>
                                    </span>
                                    <p class="lead">
                                        <a href="<?php echo e(Forum::route('thread.show', $thread)); ?>"><?php echo e($thread->title); ?></a>
                                    </p>
                                    <p><?php echo e($thread->authorName); ?> <span class="text-muted">(<?php echo e($thread->posted); ?>)</span></p>
                                </td>
                                <?php if($thread->trashed()): ?>
                                    <td colspan="2">&nbsp;</td>
                                <?php else: ?>
                                    <td class="text-right">
                                        <?php echo e($thread->reply_count); ?>

                                    </td>
                                    <td class="text-right">
                                        <?php echo e($thread->lastPost->authorName); ?>

                                        <p class="text-muted">(<?php echo e($thread->lastPost->posted); ?>)</p>
                                        <a href="<?php echo e(Forum::route('thread.show', $thread->lastPost)); ?>" class="btn btn-primary btn-xs"><?php echo e(trans('forum::posts.view')); ?> &raquo;</a>
                                    </td>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manageThreads', $category)): ?>
                                    <td class="text-right">
                                        <input type="checkbox" name="items[]" value="<?php echo e($thread->id); ?>">
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td>
                                <?php echo e(trans('forum::threads.none_found')); ?>

                            </td>
                            <td class="text-right" colspan="3">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createThreads', $category)): ?>
                                    <a href="<?php echo e(Forum::route('thread.create', $category)); ?>"><?php echo e(trans('forum::threads.post_the_first')); ?></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manageThreads', $category)): ?>
                <?php echo $__env->make('forum::category.partials.thread-actions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </form>
        <?php endif; ?>

        <div class="row">
            <div class="col-xs-4">
                <?php if($category->threadsEnabled): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createThreads', $category)): ?>
                        <a href="<?php echo e(Forum::route('thread.create', $category)); ?>" class="btn btn-primary"><?php echo e(trans('forum::threads.new_thread')); ?></a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="col-xs-8 text-right">
                <?php echo $threads->render(); ?>

            </div>
        </div>

        <?php if($category->threadsEnabled): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('markNewThreadsAsRead')): ?>
                <hr>
                <div class="text-center">
                    <form action="<?php echo e(Forum::route('mark-new')); ?>" method="POST" data-confirm>
                        <?php echo csrf_field(); ?>

                        <?php echo method_field('patch'); ?>

                        <input type="hidden" name="category_id" value="<?php echo e($category->id); ?>">
                        <button class="btn btn-default btn-small"><?php echo e(trans('forum::categories.mark_read')); ?></button>
                    </form>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['thread' => null], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>