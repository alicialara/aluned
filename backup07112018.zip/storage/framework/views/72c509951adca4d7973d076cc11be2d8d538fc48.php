<div class="panel panel-default hidden" data-actions data-bulk-actions>
    <div class="panel-heading"><?php echo e(trans('forum::general.with_selection')); ?></div>
    <div class="panel-body">
        <div class="form-group">
            <label for="thread-action"><?php echo e(trans_choice('forum::general.actions', 1)); ?></label>
            <select name="action" id="thread-action" class="form-control">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleteThreads', $category)): ?>
                    <option value="delete" data-confirm="true" data-method="delete"><?php echo e(trans('forum::general.delete')); ?></option>
                    <option value="restore" data-confirm="true"><?php echo e(trans('forum::general.restore')); ?></option>
                    <option value="permadelete" data-confirm="true" data-method="delete"><?php echo e(trans('forum::general.perma_delete')); ?></option>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('moveThreadsFrom', $category)): ?>
                    <option value="move"><?php echo e(trans('forum::general.move')); ?></option>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lockThreads', $category)): ?>
                    <option value="lock"><?php echo e(trans('forum::threads.lock')); ?></option>
                    <option value="unlock"><?php echo e(trans('forum::threads.unlock')); ?></option>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pinThreads', $category)): ?>
                    <option value="pin"><?php echo e(trans('forum::threads.pin')); ?></option>
                    <option value="unpin"><?php echo e(trans('forum::threads.unpin')); ?></option>
                <?php endif; ?>
            </select>
        </div>
        <div class="form-group hidden" data-depends="move">
            <label for="category-id"><?php echo e(trans_choice('forum::categories.category', 1)); ?></label>
            <select name="category_id" id="category-id" class="form-control">
                <?php echo $__env->make('forum::category.partials.options', ['hide' => $category], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </select>
        </div>
    </div>
    <div class="panel-footer clearfix">
        <button type="submit" class="btn btn-default pull-right"><?php echo e(trans('forum::general.proceed')); ?></button>
    </div>
</div>
