<?php
/**
 * Created by PhpStorm.
 * User: alicia
 * Date: 4/25/2017
 * Time: 09:44
 */


?>


<?php $__env->startSection('content'); ?>

    <h1>Creación de nuevo tema</h1>

    <div class="col-md-8">

        <?php echo Form::open(array('url' => 'temas')); ?>


        <?php echo e(Form::token()); ?>


        <div class="form-group">
            <?php echo e(Form::input('text', 'titulo', null, ['class' => 'form-control', 'placeholder' => 'Título del tema'])); ?>

        </div>


        <div class="form-group">
            <?php echo e(Form::textArea('text', 'descripcion',['class' => 'form-control', 'value' => 'Descripción del tema'])); ?>

        </div>

        <div class="form-group">
            <?php echo e(Form::submit('Crear tema', array('class' => 'btn btn-block btn-success'))); ?>

        </div>
        <?php echo Form::close(); ?>


    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>