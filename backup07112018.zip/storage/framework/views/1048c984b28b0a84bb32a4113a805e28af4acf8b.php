<div class="panel panel-default" data-actions>
    <div class="panel-heading">
        <span class="glyphicon glyphicon-option-vertical"></span>
        <a href="#" data-toggle="collapse" data-target=".collapse.category-options"><?php echo e(trans('forum::categories.actions')); ?></a>
    </div>
    <div class="collapse category-options">
        <div class="panel-body">
            <div class="form-group">
                <label for="category-action"><?php echo e(trans_choice('forum::general.actions', 1)); ?></label>
                <select name="action" id="category-action" class="form-control">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $category)): ?>
                        <option value="delete" data-confirm="true" data-method="delete"><?php echo e(trans('forum::general.delete')); ?></option>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createCategories')): ?>
                        <?php if($category->threadsEnabled): ?>
                            <option value="disable-threads"><?php echo e(trans('forum::categories.disable_threads')); ?></option>
                        <?php else: ?>
                            <option value="enable-threads"><?php echo e(trans('forum::categories.enable_threads')); ?></option>
                        <?php endif; ?>
                        <?php if($category->private): ?>
                            <option value="make-public"><?php echo e(trans('forum::categories.make_public')); ?></option>
                        <?php else: ?>
                            <option value="make-private"><?php echo e(trans('forum::categories.make_private')); ?></option>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('moveCategories')): ?>
                        <option value="move"><?php echo e(trans('forum::general.move')); ?></option>
                        <option value="reorder"><?php echo e(trans('forum::general.reorder')); ?></option>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('renameCategories')): ?>
                        <option value="rename"><?php echo e(trans('forum::general.rename')); ?></option>
                    <?php endif; ?>
                </select>
            </div>
            <div class="form-group hidden" data-depends="move">
                <label for="category-id"><?php echo e(trans_choice('forum::categories.category', 1)); ?></label>
                <select name="category_id" id="category-id" class="form-control">
                    <option value="0">(<?php echo e(trans('forum::general.none')); ?>)</option>
                    <?php echo $__env->make('forum::category.partials.options', ['hide' => $category], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </select>
            </div>
            <div class="form-group hidden" data-depends="reorder">
                <label for="new-weight"><?php echo e(trans('forum::general.weight')); ?></label>
                <input type="number" name="weight" value="<?php echo e($category->weight); ?>" class="form-control">
            </div>
            <div class="form-group hidden" data-depends="rename">
                <label for="new-title"><?php echo e(trans('forum::general.title')); ?></label>
                <input type="text" id="new-title" name="title" value="<?php echo e($category->title); ?>" class="form-control">
                <label for="new-description"><?php echo e(trans('forum::general.description')); ?></label>
                <input type="text" id="new-description" name="description" value="<?php echo e($category->description); ?>" class="form-control">
            </div>
        </div>
        <div class="panel-footer clearfix">
            <button type="submit" class="btn btn-default pull-right"><?php echo e(trans('forum::general.proceed')); ?></button>
        </div>
    </div>
</div>
