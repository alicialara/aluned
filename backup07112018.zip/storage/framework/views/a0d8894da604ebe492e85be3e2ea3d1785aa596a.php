<?php $__env->startSection('content'); ?>
    <div id="thread">
        <h2>
            <?php if($thread->trashed()): ?>
                <span class="label label-danger"><?php echo e(trans('forum::general.deleted')); ?></span>
            <?php endif; ?>
            <?php if($thread->locked): ?>
                <span class="label label-warning"><?php echo e(trans('forum::threads.locked')); ?></span>
            <?php endif; ?>
            <?php if($thread->pinned): ?>
                <span class="label label-info"><?php echo e(trans('forum::threads.pinned')); ?></span>
            <?php endif; ?>
            <?php echo e($thread->title); ?>

        </h2>

        <hr>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manageThreads', $category)): ?>
            <form action="<?php echo e(Forum::route('thread.update', $thread)); ?>" method="POST" data-actions-form>
                <?php echo csrf_field(); ?>

                <?php echo method_field('patch'); ?>


                <?php echo $__env->make('forum::thread.partials.actions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </form>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deletePosts', $thread)): ?>
            <form action="<?php echo e(Forum::route('bulk.post.update')); ?>" method="POST" data-actions-form>
                <?php echo csrf_field(); ?>

                <?php echo method_field('delete'); ?>

        <?php endif; ?>

        <div class="row">
            <div class="col-xs-4">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reply', $thread)): ?>
                    <div class="btn-group" role="group">
                        <a href="<?php echo e(Forum::route('post.create', $thread)); ?>" class="btn btn-primary"><?php echo e(trans('forum::general.new_reply')); ?></a>
                        <a href="#quick-reply" class="btn btn-primary"><?php echo e(trans('forum::general.quick_reply')); ?></a>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-xs-8 text-right">
                <?php echo $posts->render(); ?>

            </div>
        </div>

        <table class="table <?php echo e($thread->trashed() ? 'deleted' : ''); ?>">
            <thead>
                <tr>
                    <th class="col-md-2">
                        <?php echo e(trans('forum::general.author')); ?>

                    </th>
                    <th>
                        <?php echo e(trans_choice('forum::posts.post', 1)); ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deletePosts', $thread)): ?>
                            <span class="pull-right">
                                <input type="checkbox" data-toggle-all>
                            </span>
                        <?php endif; ?>
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('forum::post.partials.list', compact('post'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deletePosts', $thread)): ?>
                <?php echo $__env->make('forum::thread.partials.post-actions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </form>
        <?php endif; ?>

        <?php echo $posts->render(); ?>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reply', $thread)): ?>
            <h3><?php echo e(trans('forum::general.quick_reply')); ?></h3>
            <div id="quick-reply">
                <form method="POST" action="<?php echo e(Forum::route('post.store', $thread)); ?>">
                    <?php echo csrf_field(); ?>


                    <div class="form-group">
                        <textarea name="content" class="form-control"><?php echo e(old('content')); ?></textarea>
                    </div>

                    <div class="text-right">
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(trans('forum::general.reply')); ?></button>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
    $('tr input[type=checkbox]').change(function () {
        var postRow = $(this).closest('tr').prev('tr');
        $(this).is(':checked') ? postRow.addClass('active') : postRow.removeClass('active');
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>