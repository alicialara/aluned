<div class="panel panel-default" data-actions>
    <div class="panel-heading">
        <span class="glyphicon glyphicon-option-vertical"></span>
        <a href="#" data-toggle="collapse" data-target=".collapse.thread-actions"><?php echo e(trans('forum::threads.actions')); ?></a>
    </div>
    <div class="collapse thread-actions">
        <div class="panel-body">
            <div class="form-group">
                <label for="action"><?php echo e(trans_choice('forum::general.actions', 1)); ?></label>
                <select name="action" id="action" class="form-control">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleteThreads', $category)): ?>
                        <?php if($thread->trashed()): ?>
                            <option value="restore" data-confirm="true"><?php echo e(trans('forum::general.restore')); ?></option>
                        <?php else: ?>
                            <option value="delete" data-confirm="true" data-method="delete"><?php echo e(trans('forum::general.delete')); ?></option>
                        <?php endif; ?>
                        <option value="permadelete" data-confirm="true" data-method="delete"><?php echo e(trans('forum::general.perma_delete')); ?></option>
                    <?php endif; ?>

                    <?php if(!$thread->trashed()): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('moveThreadsFrom', $category)): ?>
                            <option value="move"><?php echo e(trans('forum::general.move')); ?></option>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lockThreads', $category)): ?>
                            <?php if($thread->locked): ?>
                                <option value="unlock"><?php echo e(trans('forum::threads.unlock')); ?></option>
                            <?php else: ?>
                                <option value="lock"><?php echo e(trans('forum::threads.lock')); ?></option>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pinThreads', $category)): ?>
                            <?php if($thread->pinned): ?>
                                <option value="unpin"><?php echo e(trans('forum::threads.unpin')); ?></option>
                            <?php else: ?>
                                <option value="pin"><?php echo e(trans('forum::threads.pin')); ?></option>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rename', $thread)): ?>
                            <option value="rename"><?php echo e(trans('forum::general.rename')); ?></option>
                        <?php endif; ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="form-group hidden" data-depends="move">
                <label for="category-id"><?php echo e(trans_choice('forum::categories.category', 1)); ?></label>
                <select name="category_id" id="category-id" class="form-control">
                    <?php echo $__env->make('forum::category.partials.options', ['hide' => $thread->category], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </select>
            </div>
            <div class="form-group hidden" data-depends="rename">
                <label for="new-title"><?php echo e(trans('forum::general.title')); ?></label>
                <input type="text" name="title" value="<?php echo e($thread->title); ?>" class="form-control">
            </div>
        </div>
        <div class="panel-footer clearfix">
            <button type="submit" class="btn btn-default pull-right"><?php echo e(trans('forum::general.proceed')); ?></button>
        </div>
    </div>
</div>
