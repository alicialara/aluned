<?php
/**
 * Created by PhpStorm.
 * User: alicia
 * Date: 4/25/2017
 * Time: 09:44
 */
?>


<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="row">
            <?php echo $__env->make('poll.tablavoting', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts_datatables'); ?>

<script>
    $(document).ready(function() {
//        $('.table').DataTable({
//            paginate: false
//        });
//
//
//        $('a[class*="selecciona_fecha_final"]').click(function(e){
//            e.preventDefault();
//            var url = $(this).attr("href");
//            $.get(url, function(data, status){
////                    alert("Data: " + data + "\nStatus: " + status);
//            });
//            location.reload();
////                $(this).html("Tema NO seleccionado").removeClass( "btn btn-sm btn-success btn-danger" );
//        });

    });
</script>




<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>