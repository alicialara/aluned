<?php
/**
 * Created by PhpStorm.
 * User: alicia
 * Date: 4/25/2017
 * Time: 09:44
 */
?>


<?php $__env->startSection('content'); ?>

            <?php echo $__env->make('poll.tablavoting', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts_datatables'); ?>

<script>

    $(document).ready(function() {


        $('.tabla_voting').DataTable({
            paginate: false,
            responsive: false
        });


        $('a[class*="selecciona_fecha_final"]').click(function(e){
            e.preventDefault();
            var url = $(this).attr("href");
            $.get(url, function(data, status){
//                    alert("Data: " + data + "\nStatus: " + status);
            });
            location.reload();
//                $(this).html("Tema NO seleccionado").removeClass( "btn btn-sm btn-success btn-danger" );
        });




    } );
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>